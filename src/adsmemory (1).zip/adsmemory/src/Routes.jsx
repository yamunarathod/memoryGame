import React from "react";
import { BrowserRouter, Routes as RouterRoutes, Route } from "react-router-dom";
import ScrollToTop from "components/ScrollToTop";
import ErrorBoundary from "components/ErrorBoundary";
// Add your imports here
import UserRegistration from "pages/user-registration";
import ExpertiseSelection from "pages/expertise-selection";
import QuestionMemorization from "pages/question-memorization";
import ResultsAndFeedback from "pages/results-and-feedback";
import DragAndDropMatching from "pages/drag-and-drop-matching";
import NotFound from "pages/NotFound";

const Routes = () => {
  return (
    <BrowserRouter>
      <ErrorBoundary>
      <ScrollToTop />
      <RouterRoutes>
        {/* Define your routes here */}
        <Route path="/" element={<UserRegistration />} />
        <Route path="/user-registration" element={<UserRegistration />} />
        <Route path="/expertise-selection" element={<ExpertiseSelection />} />
        <Route path="/question-memorization" element={<QuestionMemorization />} />
        <Route path="/results-and-feedback" element={<ResultsAndFeedback />} />
        <Route path="/drag-and-drop-matching" element={<DragAndDropMatching />} />
        <Route path="*" element={<NotFound />} />
      </RouterRoutes>
      </ErrorBoundary>
    </BrowserRouter>
  );
};

export default Routes;