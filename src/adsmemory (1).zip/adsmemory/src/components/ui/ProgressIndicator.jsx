import React from 'react';

const ProgressIndicator = ({ currentPhase, totalPhases, phases }) => {
  return (
    <div className="flex items-center space-x-3">
      {phases.slice(1).map((phase, index) => {
        const phaseNumber = index + 2; // Start from phase 2 (expertise)
        const isActive = phaseNumber === currentPhase;
        const isCompleted = phaseNumber < currentPhase;
        
        return (
          <div key={phase.id} className="flex items-center">
            {/* Phase Dot */}
            <div className="flex items-center">
              <div
                className={`w-3 h-3 rounded-full transition-all duration-200 ${
                  isCompleted
                    ? 'bg-success'
                    : isActive
                    ? 'bg-primary ring-2 ring-primary/20' :'bg-muted border border-border'
                }`}
              />
              
              {/* Phase Label - Hidden on mobile */}
              <span
                className={`ml-2 text-sm font-medium transition-colors duration-200 hidden sm:inline ${
                  isActive
                    ? 'text-primary'
                    : isCompleted
                    ? 'text-success' :'text-muted-foreground'
                }`}
              >
                {phase.label}
              </span>
            </div>
            
            {/* Connector Line */}
            {index < phases.slice(1).length - 1 && (
              <div
                className={`w-8 h-0.5 mx-3 transition-colors duration-200 ${
                  phaseNumber < currentPhase ? 'bg-success' : 'bg-muted'
                }`}
              />
            )}
          </div>
        );
      })}
    </div>
  );
};

export default ProgressIndicator;