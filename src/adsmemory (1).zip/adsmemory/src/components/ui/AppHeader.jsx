import React from 'react';
import Icon from '../AppIcon';
import ProgressIndicator from './ProgressIndicator';
import SessionActions from './SessionActions';

const AppHeader = ({ currentPhase = 'registration', userSession = null }) => {
  const phases = [
    { id: 'registration', label: 'Registration', path: '/user-registration' },
    { id: 'expertise', label: 'Expertise', path: '/expertise-selection' },
    { id: 'memorization', label: 'Memorization', path: '/question-memorization' },
    { id: 'matching', label: 'Matching', path: '/drag-and-drop-matching' },
    { id: 'results', label: 'Results', path: '/results-and-feedback' }
  ];

  const currentPhaseIndex = phases.findIndex(phase => phase.id === currentPhase);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-card border-b border-border">
      <div className="flex items-center justify-between h-16 px-6">
        {/* Brand Logo */}
        <div className="flex items-center">
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Icon name="Brain" size={20} color="white" strokeWidth={2.5} />
            </div>
            <span className="text-xl font-bold text-foreground font-sans">
              AdsMemory
            </span>
          </div>
        </div>

        {/* Progress Indicator - Only show after registration */}
        <div className="flex-1 flex justify-center">
          {currentPhaseIndex > 0 && (
            <ProgressIndicator 
              currentPhase={currentPhaseIndex + 1} 
              totalPhases={phases.length}
              phases={phases}
            />
          )}
        </div>

        {/* Session Actions */}
        <div className="flex items-center">
          <SessionActions userSession={userSession} />
        </div>
      </div>
    </header>
  );
};

export default AppHeader;