import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../../components/ui/AppHeader';
import CountdownTimer from './components/CountdownTimer';
import QuestionsList from './components/QuestionsList';
import MemorizationHeader from './components/MemorizationHeader';
import PreparationModal from './components/PreparationModal';

const QuestionMemorization = () => {
  const navigate = useNavigate();
  const [showPreparation, setShowPreparation] = useState(false);
  const [highlightedQuestion, setHighlightedQuestion] = useState(-1);

  // Mock user session data
  const userSession = {
    name: "Alex Johnson",
    email: "alex.johnson@email.com",
    expertise: "expert",
    avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face"
  };

  // Mock questions based on expertise level
  const questions = [
    {
      id: 1,
      text: "What is the primary goal of programmatic advertising in digital marketing campaigns?",
      category: "Programmatic",
      difficulty: "expert"
    },
    {
      id: 2,
      text: "Which metric is most important for measuring brand awareness in display advertising?",
      category: "Metrics",
      difficulty: "expert"
    },
    {
      id: 3,
      text: "What does CPM stand for in advertising terminology?",
      category: "Terminology",
      difficulty: "beginner"
    },
    {
      id: 4,
      text: "How does real-time bidding (RTB) work in programmatic advertising platforms?",
      category: "Programmatic",
      difficulty: "expert"
    },
    {
      id: 5,
      text: "What is the difference between reach and frequency in media planning?",
      category: "Media Planning",
      difficulty: "intermediate"
    },
    {
      id: 6,
      text: "Which attribution model gives equal credit to all touchpoints in the customer journey?",
      category: "Attribution",
      difficulty: "expert"
    }
  ];

  // Shuffle questions for randomization
  const [shuffledQuestions] = useState(() => {
    const shuffled = [...questions];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  });

  // Handle timer completion
  const handleTimeUp = () => {
    setShowPreparation(true);
  };

  // Handle preparation completion
  const handlePreparationComplete = () => {
    // Store questions in sessionStorage for the matching phase
    sessionStorage.setItem('memorizationQuestions', JSON.stringify(shuffledQuestions));
    sessionStorage.setItem('userSession', JSON.stringify(userSession));
    navigate('/drag-and-drop-matching');
  };

  // Highlight questions periodically during countdown
  useEffect(() => {
    const highlightInterval = setInterval(() => {
      setHighlightedQuestion(prev => {
        const next = (prev + 1) % shuffledQuestions.length;
        return next;
      });
    }, 3000);

    return () => clearInterval(highlightInterval);
  }, [shuffledQuestions.length]);

  return (
    <div className="min-h-screen bg-background">
      {/* App Header */}
      <AppHeader currentPhase="memorization" userSession={userSession} />

      {/* Main Content */}
      <div className="pt-16">
        {/* Memorization Header */}
        <MemorizationHeader currentPhase="memorization" userSession={userSession} />

        {/* Content Area */}
        <div className="max-w-6xl mx-auto px-4 py-8">
          {/* Countdown Timer */}
          <div className="mb-8">
            <CountdownTimer
              initialTime={30}
              onTimeUp={handleTimeUp}
              isActive={true}
            />
          </div>

          {/* Questions List */}
          <QuestionsList 
            questions={shuffledQuestions}
            highlightedIndex={highlightedQuestion}
          />

          {/* Instructions */}
          <div className="mt-8 text-center">
            <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full">
              <span className="w-2 h-2 bg-primary rounded-full animate-pulse"></span>
              <span className="text-sm font-medium">
                Memorization in progress...
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Preparation Modal */}
      <PreparationModal
        isVisible={showPreparation}
        onComplete={handlePreparationComplete}
      />
    </div>
  );
};

export default QuestionMemorization;