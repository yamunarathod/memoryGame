import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const CountdownTimer = ({ initialTime = 30, onTimeUp, isActive = true }) => {
  const [timeLeft, setTimeLeft] = useState(initialTime);
  const [isRunning, setIsRunning] = useState(isActive);

  useEffect(() => {
    if (!isRunning || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          setIsRunning(false);
          onTimeUp?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [isRunning, timeLeft, onTimeUp]);

  const getTimerColor = () => {
    const percentage = (timeLeft / initialTime) * 100;
    if (percentage > 60) return 'text-success bg-success/10 border-success/20';
    if (percentage > 30) return 'text-warning bg-warning/10 border-warning/20';
    return 'text-error bg-error/10 border-error/20';
  };

  const getProgressWidth = () => {
    return (timeLeft / initialTime) * 100;
  };

  return (
    <div className="w-full max-w-md mx-auto">
      {/* Timer Display */}
      <div className={`relative p-6 rounded-2xl border-2 transition-all duration-300 ${getTimerColor()}`}>
        <div className="text-center">
          <div className="flex items-center justify-center mb-2">
            <Icon name="Clock" size={24} className="mr-2" />
            <span className="text-sm font-medium uppercase tracking-wide">
              Memorization Time
            </span>
          </div>
          
          <div className="text-4xl font-bold font-mono mb-2">
            {timeLeft}
          </div>
          
          <div className="text-sm opacity-80">
            seconds remaining
          </div>
        </div>

        {/* Progress Bar */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-black/10 rounded-b-2xl overflow-hidden">
          <div 
            className="h-full bg-current transition-all duration-1000 ease-linear"
            style={{ width: `${getProgressWidth()}%` }}
          />
        </div>
      </div>

      {/* Status Message */}
      <div className="text-center mt-4">
        {timeLeft > 0 ? (
          <p className="text-sm text-muted-foreground">
            Study the questions carefully. You'll need to match them with answers next!
          </p>
        ) : (
          <p className="text-sm font-medium text-primary">
            Time's up! Preparing matching challenge...
          </p>
        )}
      </div>
    </div>
  );
};

export default CountdownTimer;