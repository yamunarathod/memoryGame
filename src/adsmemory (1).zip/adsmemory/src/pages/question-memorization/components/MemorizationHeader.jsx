import React from 'react';
import Icon from '../../../components/AppIcon';

const MemorizationHeader = ({ currentPhase = 'memorization', userSession }) => {
  return (
    <div className="bg-card border-b border-border">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          {/* Phase Indicator */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-secondary rounded-full flex items-center justify-center">
              <Icon name="Brain" size={20} color="white" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">
                Phase 3: Memorization
              </h1>
              <p className="text-sm text-muted-foreground">
                Study the questions carefully
              </p>
            </div>
          </div>

          {/* User Info */}
          {userSession && (
            <div className="flex items-center space-x-2">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-medium text-foreground">
                  {userSession.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {userSession.expertise === 'expert' ? 'Ad Expert' : 'New to Ads'}
                </p>
              </div>
              {userSession.avatar ? (
                <img
                  src={userSession.avatar}
                  alt={userSession.name}
                  className="w-8 h-8 rounded-full object-cover"
                />
              ) : (
                <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
                  <Icon name="User" size={16} color="white" />
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default MemorizationHeader;