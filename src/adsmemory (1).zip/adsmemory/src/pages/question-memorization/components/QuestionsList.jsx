import React from 'react';
import QuestionCard from './QuestionCard';

const QuestionsList = ({ questions, highlightedIndex = -1 }) => {
  return (
    <div className="w-full max-w-4xl mx-auto">
      {/* Header */}
      <div className="text-center mb-6">
        <h2 className="text-2xl font-bold text-foreground mb-2">
          Study These Questions
        </h2>
        <p className="text-muted-foreground">
          Memorize the questions below. You'll match them with answers in the next phase.
        </p>
      </div>

      {/* Questions Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:gap-6">
        {questions.map((question, index) => (
          <QuestionCard
            key={question.id}
            question={question}
            index={index}
            isHighlighted={index === highlightedIndex}
          />
        ))}
      </div>

      {/* Study Tips */}
      <div className="mt-8 p-4 bg-muted/50 rounded-xl border border-border">
        <div className="flex items-start space-x-3">
          <div className="flex-shrink-0 w-8 h-8 bg-accent/20 rounded-full flex items-center justify-center">
            <span className="text-accent font-bold text-sm">💡</span>
          </div>
          <div>
            <h3 className="font-medium text-foreground mb-1">Study Tips</h3>
            <ul className="text-sm text-muted-foreground space-y-1">
              <li>• Read each question carefully and try to understand the key concepts</li>
              <li>• Look for keywords that will help you identify the correct answers</li>
              <li>• Pay attention to question categories and topics</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuestionsList;