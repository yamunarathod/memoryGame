import React from 'react';
import Icon from '../../../components/AppIcon';

const QuestionCard = ({ question, index, isHighlighted = false }) => {
  return (
    <div className={`bg-card border border-border rounded-xl p-4 transition-all duration-200 hover:shadow-md ${
      isHighlighted ? 'ring-2 ring-primary/20 bg-primary/5' : ''
    }`}>
      <div className="flex items-start space-x-3">
        {/* Question Number */}
        <div className="flex-shrink-0 w-8 h-8 bg-primary rounded-full flex items-center justify-center">
          <span className="text-sm font-bold text-primary-foreground">
            {index + 1}
          </span>
        </div>

        {/* Question Content */}
        <div className="flex-1 min-w-0">
          <p className="text-foreground font-medium leading-relaxed">
            {question.text}
          </p>
          
          {/* Question Category Badge */}
          {question.category && (
            <div className="flex items-center mt-2">
              <Icon name="Tag" size={14} className="text-muted-foreground mr-1" />
              <span className="text-xs text-muted-foreground bg-muted px-2 py-1 rounded-full">
                {question.category}
              </span>
            </div>
          )}
        </div>

        {/* Memory Hint Icon */}
        <div className="flex-shrink-0">
          <Icon name="Brain" size={20} className="text-muted-foreground" />
        </div>
      </div>
    </div>
  );
};

export default QuestionCard;