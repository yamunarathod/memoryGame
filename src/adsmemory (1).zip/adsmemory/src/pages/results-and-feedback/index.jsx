import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../../components/ui/AppHeader';
import ScoreDisplay from './components/ScoreDisplay';
import FeedbackMessage from './components/FeedbackMessage';
import PerformanceInsights from './components/PerformanceInsights';
import ActionButtons from './components/ActionButtons';
import ProgressSummary from './components/ProgressSummary';

const ResultsAndFeedback = () => {
  const navigate = useNavigate();
  const [gameResults, setGameResults] = useState(null);
  const [userSession, setUserSession] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Load game results and user session from localStorage
    const loadGameData = () => {
      try {
        const storedResults = localStorage.getItem('gameResults');
        const storedSession = localStorage.getItem('userSession');
        
        if (!storedResults) {
          // If no results found, redirect to start
          navigate('/user-registration');
          return;
        }

        const results = JSON.parse(storedResults);
        const session = storedSession ? JSON.parse(storedSession) : null;

        // Mock data structure for demonstration
        const mockResults = {
          score: results.score || 75,
          totalQuestions: results.totalQuestions || 6,
          correctAnswers: results.correctAnswers || 4,
          timeTaken: results.timeTaken || 165, // seconds
          difficultyLevel: results.difficultyLevel || 'beginner',
          averageTime: 30, // average time per question
          completedAt: new Date().toISOString(),
          ...results
        };

        const mockSession = {
          name: session?.name || 'John Doe',
          email: session?.email || 'john.doe@example.com',
          expertise: session?.expertise || 'beginner',
          avatar: session?.avatar || null,
          ...session
        };

        setGameResults(mockResults);
        setUserSession(mockSession);
      } catch (error) {
        console.error('Error loading game data:', error);
        navigate('/user-registration');
      } finally {
        setLoading(false);
      }
    };

    loadGameData();
  }, [navigate]);

  const handleShare = () => {
    // Track sharing analytics or perform additional actions
    console.log('Results shared successfully');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader currentPhase="results" userSession={userSession} />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
            <p className="text-muted-foreground">Loading your results...</p>
          </div>
        </div>
      </div>
    );
  }

  if (!gameResults) {
    return (
      <div className="min-h-screen bg-background">
        <AppHeader currentPhase="results" userSession={userSession} />
        <div className="pt-16 flex items-center justify-center min-h-screen">
          <div className="text-center">
            <p className="text-muted-foreground mb-4">No results found</p>
            <button 
              onClick={() => navigate('/user-registration')}
              className="text-primary hover:underline"
            >
              Start New Assessment
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <AppHeader currentPhase="results" userSession={userSession} />
      
      <main className="pt-16">
        <div className="container mx-auto px-4 py-8 max-w-4xl">
          {/* Header Section */}
          <div className="text-center mb-8">
            <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-2">
              Assessment Complete!
            </h1>
            <p className="text-muted-foreground">
              Here's how you performed on the AdsMemory challenge
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Main Results Column */}
            <div className="lg:col-span-2 space-y-8">
              {/* Score Display */}
              <div className="bg-card border border-border rounded-lg p-6">
                <ScoreDisplay
                  score={gameResults.score}
                  totalQuestions={gameResults.totalQuestions}
                  correctAnswers={gameResults.correctAnswers}
                  timeTaken={gameResults.timeTaken}
                  difficultyLevel={gameResults.difficultyLevel}
                />
              </div>

              {/* Feedback Message */}
              <FeedbackMessage
                score={gameResults.score}
                totalQuestions={gameResults.totalQuestions}
                correctAnswers={gameResults.correctAnswers}
                userName={userSession?.name}
              />

              {/* Performance Insights */}
              <div className="bg-card border border-border rounded-lg p-6">
                <PerformanceInsights
                  correctAnswers={gameResults.correctAnswers}
                  totalQuestions={gameResults.totalQuestions}
                  timeTaken={gameResults.timeTaken}
                  difficultyLevel={gameResults.difficultyLevel}
                  averageTime={gameResults.averageTime}
                />
              </div>

              {/* Action Buttons */}
              <div className="bg-card border border-border rounded-lg p-6">
                <ActionButtons
                  score={gameResults.score}
                  difficultyLevel={gameResults.difficultyLevel}
                  onShare={handleShare}
                />
              </div>
            </div>

            {/* Sidebar */}
            <div className="lg:col-span-1">
              <div className="sticky top-24">
                <ProgressSummary
                  userSession={userSession}
                  gameStats={{
                    matchingTime: `${gameResults.timeTaken}s`,
                    completedAt: gameResults.completedAt
                  }}
                />
              </div>
            </div>
          </div>

          {/* Footer Message */}
          <div className="text-center mt-12 py-8 border-t border-border">
            <p className="text-muted-foreground mb-4">
              Thank you for taking the AdsMemory assessment!
            </p>
            <p className="text-sm text-muted-foreground">
              Assessment completed on {new Date().toLocaleDateString('en-US', {
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: '2-digit',
                minute: '2-digit'
              })}
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ResultsAndFeedback;