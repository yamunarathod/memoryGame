import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressSummary = ({ userSession, gameStats }) => {
  const phases = [
    { 
      id: 'registration', 
      label: 'Registration', 
      icon: 'UserPlus',
      completed: true,
      time: '30s'
    },
    { 
      id: 'expertise', 
      label: 'Expertise Selection', 
      icon: 'Target',
      completed: true,
      time: '15s'
    },
    { 
      id: 'memorization', 
      label: 'Question Memorization', 
      icon: 'Brain',
      completed: true,
      time: '30s'
    },
    { 
      id: 'matching', 
      label: 'Drag & Drop Matching', 
      icon: 'Move',
      completed: true,
      time: gameStats?.matchingTime || '180s'
    },
    { 
      id: 'results', 
      label: 'Results & Feedback', 
      icon: 'Award',
      completed: true,
      time: 'Current'
    }
  ];

  const totalTime = phases.reduce((acc, phase) => {
    if (phase.time === 'Current') return acc;
    const timeInSeconds = parseInt(phase.time);
    return acc + timeInSeconds;
  }, 0);

  return (
    <div className="bg-card border border-border rounded-lg p-6">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-lg font-semibold text-foreground">
          Assessment Journey
        </h3>
        <div className="text-sm text-muted-foreground">
          Total Time: {Math.floor(totalTime / 60)}:{(totalTime % 60).toString().padStart(2, '0')}
        </div>
      </div>

      <div className="space-y-4">
        {phases.map((phase, index) => (
          <div key={phase.id} className="flex items-center space-x-4">
            {/* Phase Icon */}
            <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center ${
              phase.completed 
                ? 'bg-success text-white' :'bg-muted text-muted-foreground'
            }`}>
              <Icon 
                name={phase.icon} 
                size={16} 
                strokeWidth={2}
              />
            </div>

            {/* Phase Info */}
            <div className="flex-1">
              <div className="flex items-center justify-between">
                <span className={`font-medium ${
                  phase.completed ? 'text-foreground' : 'text-muted-foreground'
                }`}>
                  {phase.label}
                </span>
                <span className="text-sm text-muted-foreground">
                  {phase.time}
                </span>
              </div>
            </div>

            {/* Completion Check */}
            <div className="flex-shrink-0">
              {phase.completed && (
                <Icon 
                  name="Check" 
                  size={16} 
                  className="text-success"
                  strokeWidth={2}
                />
              )}
            </div>
          </div>
        ))}
      </div>

      {/* User Info Summary */}
      {userSession && (
        <div className="mt-6 pt-4 border-t border-border">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
              <Icon name="User" size={16} color="white" />
            </div>
            <div>
              <p className="text-sm font-medium text-foreground">
                {userSession.name}
              </p>
              <p className="text-xs text-muted-foreground">
                {userSession.email} • {userSession.expertise} Level
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ProgressSummary;