import React from 'react';
import Icon from '../../../components/AppIcon';

const FeedbackMessage = ({ score, totalQuestions, correctAnswers, userName }) => {
  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  
  const getFeedbackContent = () => {
    if (percentage === 0) {
      return {
        title: "Don't Give Up!",
        message: `Hey ${userName || 'there'}, everyone starts somewhere! This was just your first attempt, and now you know what to expect. Take some time to review the concepts and try again when you're ready.`,
        icon: 'Heart',
        iconColor: 'text-primary',
        bgColor: 'bg-primary/10',
        borderColor: 'border-primary/20'
      };
    } else if (percentage < 40) {
      return {
        title: "Keep Learning!",
        message: `Good effort, ${userName || 'there'}! You got ${correctAnswers} questions right. With a bit more practice and review, you'll definitely improve. Every expert was once a beginner!`,
        icon: 'BookOpen',
        iconColor: 'text-accent',
        bgColor: 'bg-accent/10',
        borderColor: 'border-accent/20'
      };
    } else if (percentage < 70) {
      return {
        title: "Nice Progress!",
        message: `Well done, ${userName || 'there'}! You're getting the hang of it with ${correctAnswers} correct answers. You're on the right track - keep building on this foundation!`,
        icon: 'TrendingUp',
        iconColor: 'text-primary',
        bgColor: 'bg-primary/10',
        borderColor: 'border-primary/20'
      };
    } else if (percentage < 90) {
      return {
        title: "Great Job!",
        message: `Excellent work, ${userName || 'there'}! You scored ${correctAnswers} out of ${totalQuestions} - that's impressive! You clearly have a solid understanding of the concepts.`,
        icon: 'Award',
        iconColor: 'text-success',
        bgColor: 'bg-success/10',
        borderColor: 'border-success/20'
      };
    } else {
      return {
        title: "Outstanding Performance!",
        message: `Congratulations, ${userName || 'there'}! You achieved an exceptional score of ${correctAnswers} out of ${totalQuestions}. You've demonstrated mastery of the advertising concepts - truly impressive!`,
        icon: 'Trophy',
        iconColor: 'text-success',
        bgColor: 'bg-success/10',
        borderColor: 'border-success/20'
      };
    }
  };

  const feedback = getFeedbackContent();

  return (
    <div className={`rounded-lg border-2 ${feedback.borderColor} ${feedback.bgColor} p-6`}>
      <div className="flex items-start space-x-4">
        <div className={`flex-shrink-0 w-12 h-12 rounded-full bg-card border-2 ${feedback.borderColor} flex items-center justify-center`}>
          <Icon 
            name={feedback.icon} 
            size={24} 
            className={feedback.iconColor}
            strokeWidth={2}
          />
        </div>
        
        <div className="flex-1">
          <h3 className="text-xl font-bold text-foreground mb-2">
            {feedback.title}
          </h3>
          <p className="text-muted-foreground leading-relaxed">
            {feedback.message}
          </p>
        </div>
      </div>
    </div>
  );
};

export default FeedbackMessage;