import React from 'react';
import Icon from '../../../components/AppIcon';

const PerformanceInsights = ({ correctAnswers, totalQuestions, timeTaken, difficultyLevel, averageTime }) => {
  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  const timePerQuestion = Math.round(timeTaken / totalQuestions);
  
  const insights = [
    {
      icon: 'Target',
      label: 'Accuracy Rate',
      value: `${percentage}%`,
      description: `${correctAnswers} correct out of ${totalQuestions} questions`,
      color: percentage >= 70 ? 'text-success' : percentage >= 40 ? 'text-warning' : 'text-muted-foreground'
    },
    {
      icon: 'Clock',
      label: 'Average Time',
      value: `${timePerQuestion}s`,
      description: `Per question (${Math.floor(timeTaken / 60)}:${(timeTaken % 60).toString().padStart(2, '0')} total)`,
      color: timePerQuestion <= averageTime ? 'text-success' : 'text-primary'
    },
    {
      icon: 'BarChart3',
      label: 'Difficulty Level',
      value: difficultyLevel === 'expert' ? 'Expert' : 'Beginner',
      description: difficultyLevel === 'expert' ? 'Advanced advertising concepts' : 'Fundamental advertising basics',
      color: 'text-primary'
    },
    {
      icon: 'Zap',
      label: 'Performance',
      value: getPerformanceLevel(percentage),
      description: getPerformanceDescription(percentage),
      color: getPerformanceColor(percentage)
    }
  ];

  function getPerformanceLevel(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 70) return 'Good';
    if (score >= 40) return 'Fair';
    return 'Needs Work';
  }

  function getPerformanceDescription(score) {
    if (score >= 90) return 'Outstanding mastery of concepts';
    if (score >= 70) return 'Solid understanding demonstrated';
    if (score >= 40) return 'Basic concepts grasped';
    return 'More practice recommended';
  }

  function getPerformanceColor(score) {
    if (score >= 70) return 'text-success';
    if (score >= 40) return 'text-warning';
    return 'text-muted-foreground';
  }

  return (
    <div className="space-y-4">
      <h3 className="text-lg font-semibold text-foreground mb-4">
        Performance Insights
      </h3>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {insights.map((insight, index) => (
          <div key={index} className="bg-card border border-border rounded-lg p-4">
            <div className="flex items-start space-x-3">
              <div className="flex-shrink-0">
                <div className="w-10 h-10 rounded-lg bg-muted flex items-center justify-center">
                  <Icon 
                    name={insight.icon} 
                    size={20} 
                    className={insight.color}
                    strokeWidth={2}
                  />
                </div>
              </div>
              
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <p className="text-sm font-medium text-muted-foreground">
                    {insight.label}
                  </p>
                  <span className={`text-lg font-bold ${insight.color}`}>
                    {insight.value}
                  </span>
                </div>
                <p className="text-xs text-muted-foreground">
                  {insight.description}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default PerformanceInsights;