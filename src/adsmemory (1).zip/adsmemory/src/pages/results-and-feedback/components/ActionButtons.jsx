import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import Button from '../../../components/ui/Button';


const ActionButtons = ({ score, difficultyLevel, onShare }) => {
  const navigate = useNavigate();
  const [isSharing, setIsSharing] = useState(false);

  const handlePlayAgain = () => {
    // Clear any stored game state and restart
    localStorage.removeItem('gameProgress');
    localStorage.removeItem('userAnswers');
    localStorage.removeItem('gameTimer');
    navigate('/question-memorization');
  };

  const handleTryDifferentLevel = () => {
    // Clear game state and go back to expertise selection
    localStorage.removeItem('gameProgress');
    localStorage.removeItem('userAnswers');
    localStorage.removeItem('gameTimer');
    navigate('/expertise-selection');
  };

  const handleShareResults = async () => {
    setIsSharing(true);
    
    try {
      const shareData = {
        title: 'AdsMemory Assessment Results',
        text: `I just completed the AdsMemory assessment and scored ${score}%! Test your advertising knowledge too.`,
        url: window.location.origin
      };

      if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
        await navigator.share(shareData);
      } else {
        // Fallback to clipboard
        const shareText = `I just completed the AdsMemory assessment and scored ${score}%! Test your advertising knowledge at ${window.location.origin}`;
        await navigator.clipboard.writeText(shareText);
        
        // Show success feedback
        const button = document.getElementById('share-button');
        const originalText = button.textContent;
        button.textContent = 'Copied to Clipboard!';
        setTimeout(() => {
          button.textContent = originalText;
        }, 2000);
      }
      
      if (onShare) {
        onShare();
      }
    } catch (error) {
      console.error('Error sharing:', error);
    } finally {
      setIsSharing(false);
    }
  };

  const handleBackToStart = () => {
    // Clear all game state and go to registration
    localStorage.clear();
    navigate('/user-registration');
  };

  return (
    <div className="space-y-4">
      {/* Primary Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Button
          variant="default"
          size="lg"
          fullWidth
          iconName="RotateCcw"
          iconPosition="left"
          onClick={handlePlayAgain}
          className="h-12"
        >
          Play Again
        </Button>
        
        <Button
          variant="outline"
          size="lg"
          fullWidth
          iconName="Settings"
          iconPosition="left"
          onClick={handleTryDifferentLevel}
          className="h-12"
        >
          Try Different Level
        </Button>
      </div>

      {/* Secondary Actions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <Button
          id="share-button"
          variant="secondary"
          size="default"
          fullWidth
          iconName="Share2"
          iconPosition="left"
          loading={isSharing}
          onClick={handleShareResults}
        >
          Share Results
        </Button>
        
        <Button
          variant="ghost"
          size="default"
          fullWidth
          iconName="Home"
          iconPosition="left"
          onClick={handleBackToStart}
        >
          Back to Start
        </Button>
      </div>

      {/* Additional Info */}
      <div className="text-center pt-4 border-t border-border">
        <p className="text-sm text-muted-foreground mb-2">
          Want to improve your score?
        </p>
        <div className="flex flex-col sm:flex-row gap-2 justify-center">
          <Button
            variant="link"
            size="sm"
            iconName="BookOpen"
            iconPosition="left"
            onClick={() => window.open('https://example.com/study-guide', '_blank')}
          >
            Study Guide
          </Button>
          <Button
            variant="link"
            size="sm"
            iconName="Users"
            iconPosition="left"
            onClick={() => window.open('https://example.com/community', '_blank')}
          >
            Join Community
          </Button>
        </div>
      </div>
    </div>
  );
};

export default ActionButtons;