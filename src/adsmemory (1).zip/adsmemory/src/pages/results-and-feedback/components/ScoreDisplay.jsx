import React from 'react';
import Icon from '../../../components/AppIcon';

const ScoreDisplay = ({ score, totalQuestions, correctAnswers, timeTaken, difficultyLevel }) => {
  const percentage = Math.round((correctAnswers / totalQuestions) * 100);
  const isPassing = percentage > 0;
  
  const getScoreColor = () => {
    if (percentage >= 80) return 'text-success';
    if (percentage >= 60) return 'text-primary';
    if (percentage >= 40) return 'text-warning';
    return 'text-muted-foreground';
  };

  const getScoreIcon = () => {
    if (percentage >= 80) return 'Trophy';
    if (percentage >= 60) return 'Award';
    if (percentage >= 40) return 'Target';
    return 'RotateCcw';
  };

  return (
    <div className="text-center space-y-6">
      {/* Score Circle */}
      <div className="relative inline-flex items-center justify-center">
        <div className="w-32 h-32 sm:w-40 sm:h-40 rounded-full border-8 border-muted flex items-center justify-center bg-card">
          <div className="text-center">
            <div className={`text-4xl sm:text-5xl font-bold ${getScoreColor()}`}>
              {percentage}%
            </div>
            <div className="text-sm text-muted-foreground mt-1">
              Score
            </div>
          </div>
        </div>
        
        {/* Achievement Icon */}
        <div className={`absolute -top-2 -right-2 w-12 h-12 rounded-full flex items-center justify-center ${
          isPassing ? 'bg-success' : 'bg-muted'
        }`}>
          <Icon 
            name={getScoreIcon()} 
            size={24} 
            color="white" 
            strokeWidth={2}
          />
        </div>
      </div>

      {/* Score Breakdown */}
      <div className="bg-muted rounded-lg p-4 space-y-3">
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Correct Answers</span>
          <span className="font-semibold text-foreground">
            {correctAnswers} / {totalQuestions}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Time Taken</span>
          <span className="font-semibold text-foreground">
            {Math.floor(timeTaken / 60)}:{(timeTaken % 60).toString().padStart(2, '0')}
          </span>
        </div>
        
        <div className="flex justify-between items-center">
          <span className="text-sm text-muted-foreground">Difficulty Level</span>
          <span className="font-semibold text-foreground capitalize">
            {difficultyLevel}
          </span>
        </div>
      </div>
    </div>
  );
};

export default ScoreDisplay;