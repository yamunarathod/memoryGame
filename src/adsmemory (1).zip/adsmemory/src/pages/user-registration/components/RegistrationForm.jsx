import React, { useState } from 'react';
import Input from '../../../components/ui/Input';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const RegistrationForm = ({ onSubmit, isLoading }) => {
  const [email, setEmail] = useState('');
  const [errors, setErrors] = useState({});
  const [isValidating, setIsValidating] = useState(false);

  const validateEmail = (emailValue) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailValue) {
      return 'Email address is required';
    }
    if (!emailRegex.test(emailValue)) {
      return 'Please enter a valid email address';
    }
    return '';
  };

  const handleEmailChange = async (e) => {
    const value = e.target.value;
    setEmail(value);
    
    // Clear previous errors
    setErrors({});
    
    if (value) {
      setIsValidating(true);
      
      // Simulate email validation delay
      setTimeout(() => {
        const emailError = validateEmail(value);
        if (emailError) {
          setErrors({ email: emailError });
        } else {
          // Simulate checking if email already exists
          const existingEmails = ['test@example.com', 'admin@adsmemory.com'];
          if (existingEmails.includes(value.toLowerCase())) {
            setErrors({ email: 'This email address is already registered' });
          }
        }
        setIsValidating(false);
      }, 500);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    const emailError = validateEmail(email);
    if (emailError) {
      setErrors({ email: emailError });
      return;
    }

    // Check for existing email
    const existingEmails = ['test@example.com', 'admin@adsmemory.com'];
    if (existingEmails.includes(email.toLowerCase())) {
      setErrors({ email: 'This email address is already registered' });
      return;
    }

    onSubmit({ email });
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="space-y-2">
        <Input
          label="Email Address"
          type="email"
          placeholder="Enter your email address"
          value={email}
          onChange={handleEmailChange}
          error={errors.email}
          required
          disabled={isLoading}
          className="w-full"
        />
        
        {isValidating && (
          <div className="flex items-center space-x-2 text-sm text-muted-foreground">
            <div className="w-4 h-4 border-2 border-primary border-t-transparent rounded-full animate-spin" />
            <span>Validating email...</span>
          </div>
        )}
        
        {email && !errors.email && !isValidating && (
          <div className="flex items-center space-x-2 text-sm text-success">
            <Icon name="CheckCircle" size={16} />
            <span>Email is available</span>
          </div>
        )}
      </div>

      <Button
        type="submit"
        variant="default"
        size="lg"
        fullWidth
        loading={isLoading}
        disabled={!email || !!errors.email || isValidating}
        iconName="ArrowRight"
        iconPosition="right"
      >
        Create Account
      </Button>

      <div className="text-center">
        <p className="text-sm text-muted-foreground">
          By creating an account, you agree to our{' '}
          <button
            type="button"
            className="text-primary hover:underline focus:outline-none focus:underline"
            onClick={() => console.log('Terms clicked')}
          >
            Terms of Service
          </button>
          {' '}and{' '}
          <button
            type="button"
            className="text-primary hover:underline focus:outline-none focus:underline"
            onClick={() => console.log('Privacy clicked')}
          >
            Privacy Policy
          </button>
        </p>
      </div>
    </form>
  );
};

export default RegistrationForm;