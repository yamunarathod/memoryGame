import React from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const ErrorMessage = ({ error, onRetry, onGoBack }) => {
  const getErrorDetails = (errorType) => {
    switch (errorType) {
      case 'network':
        return {
          title: 'Connection Error',
          message: 'Unable to connect to our servers. Please check your internet connection and try again.',
          icon: 'WifiOff',
          color: 'text-warning'
        };
      case 'server':
        return {
          title: 'Server Error',
          message: 'Our servers are experiencing issues. Please try again in a few moments.',
          icon: 'ServerCrash',
          color: 'text-error'
        };
      case 'validation':
        return {
          title: 'Validation Error',
          message: 'Please check your information and try again.',
          icon: 'AlertCircle',
          color: 'text-warning'
        };
      default:
        return {
          title: 'Something Went Wrong',
          message: 'An unexpected error occurred. Please try again.',
          icon: 'AlertTriangle',
          color: 'text-error'
        };
    }
  };

  const errorDetails = getErrorDetails(error?.type || 'default');

  return (
    <div className="text-center space-y-6">
      {/* Error Icon */}
      <div className="flex justify-center">
        <div className="w-20 h-20 bg-muted rounded-full flex items-center justify-center">
          <Icon 
            name={errorDetails.icon} 
            size={40} 
            className={errorDetails.color}
            strokeWidth={2}
          />
        </div>
      </div>

      {/* Error Message */}
      <div className="space-y-3">
        <h2 className="text-2xl font-bold text-foreground">
          {errorDetails.title}
        </h2>
        <p className="text-muted-foreground max-w-md mx-auto">
          {error?.message || errorDetails.message}
        </p>
      </div>

      {/* Action Buttons */}
      <div className="space-y-3">
        <Button
          variant="default"
          size="lg"
          onClick={onRetry}
          iconName="RefreshCw"
          iconPosition="left"
          fullWidth
        >
          Try Again
        </Button>
        
        <Button
          variant="outline"
          size="default"
          onClick={onGoBack}
          iconName="ArrowLeft"
          iconPosition="left"
          fullWidth
        >
          Go Back
        </Button>
      </div>

      {/* Help Text */}
      <div className="text-sm text-muted-foreground">
        <p>
          If the problem persists, please{' '}
          <button
            className="text-primary hover:underline focus:outline-none focus:underline"
            onClick={() => console.log('Contact support')}
          >
            contact our support team
          </button>
        </p>
      </div>
    </div>
  );
};

export default ErrorMessage;