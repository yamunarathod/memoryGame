import React from 'react';
import Icon from '../../../components/AppIcon';

const WelcomeHeader = () => {
  return (
    <div className="text-center space-y-4 mb-8">
      {/* App Logo */}
      <div className="flex justify-center">
        <div className="w-16 h-16 bg-primary rounded-2xl flex items-center justify-center shadow-lg">
          <Icon name="Brain" size={32} color="white" strokeWidth={2.5} />
        </div>
      </div>

      {/* Welcome Text */}
      <div className="space-y-2">
        <h1 className="text-3xl font-bold text-foreground">
          Welcome to AdsMemory
        </h1>
        <p className="text-lg text-muted-foreground max-w-md mx-auto">
          Test and improve your advertising knowledge through interactive memory challenges
        </p>
      </div>

      {/* Features List */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-6 text-sm">
        <div className="flex items-center justify-center space-x-2 text-muted-foreground">
          <Icon name="Clock" size={16} />
          <span>Timed Challenges</span>
        </div>
        <div className="flex items-center justify-center space-x-2 text-muted-foreground">
          <Icon name="Target" size={16} />
          <span>Skill Assessment</span>
        </div>
        <div className="flex items-center justify-center space-x-2 text-muted-foreground">
          <Icon name="Trophy" size={16} />
          <span>Instant Results</span>
        </div>
      </div>
    </div>
  );
};

export default WelcomeHeader;