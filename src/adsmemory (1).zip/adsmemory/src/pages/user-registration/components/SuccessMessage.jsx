import React, { useEffect } from 'react';
import Icon from '../../../components/AppIcon';
import Button from '../../../components/ui/Button';

const SuccessMessage = ({ email, onContinue }) => {
  useEffect(() => {
    // Auto-redirect after 3 seconds
    const timer = setTimeout(() => {
      onContinue();
    }, 3000);

    return () => clearTimeout(timer);
  }, [onContinue]);

  return (
    <div className="text-center space-y-6">
      {/* Success Icon */}
      <div className="flex justify-center">
        <div className="w-20 h-20 bg-success rounded-full flex items-center justify-center shadow-lg animate-pulse">
          <Icon name="CheckCircle" size={40} color="white" strokeWidth={2} />
        </div>
      </div>

      {/* Success Message */}
      <div className="space-y-3">
        <h2 className="text-2xl font-bold text-foreground">
          Account Created Successfully!
        </h2>
        <p className="text-muted-foreground">
          Welcome aboard! Your account has been created with email:
        </p>
        <p className="text-primary font-semibold bg-muted px-4 py-2 rounded-lg inline-block">
          {email}
        </p>
      </div>

      {/* Next Steps */}
      <div className="space-y-4">
        <p className="text-sm text-muted-foreground">
          You'll be automatically redirected to select your expertise level in a few seconds...
        </p>
        
        <Button
          variant="default"
          size="lg"
          onClick={onContinue}
          iconName="ArrowRight"
          iconPosition="right"
          className="mx-auto"
        >
          Continue Now
        </Button>
      </div>

      {/* Progress Indicator */}
      <div className="flex items-center justify-center space-x-2 text-sm text-muted-foreground">
        <div className="w-2 h-2 bg-success rounded-full" />
        <span>Step 1 of 4 Complete</span>
      </div>
    </div>
  );
};

export default SuccessMessage;