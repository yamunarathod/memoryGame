import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../../components/ui/AppHeader';
import WelcomeHeader from './components/WelcomeHeader';
import RegistrationForm from './components/RegistrationForm';
import SuccessMessage from './components/SuccessMessage';
import ErrorMessage from './components/ErrorMessage';

const UserRegistration = () => {
  const navigate = useNavigate();
  const [registrationState, setRegistrationState] = useState('form'); // 'form', 'loading', 'success', 'error'
  const [userEmail, setUserEmail] = useState('');
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleRegistrationSubmit = async (formData) => {
    setIsLoading(true);
    setRegistrationState('loading');
    setError(null);

    try {
      // Simulate API call delay
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Simulate random errors for demonstration (remove in production)
      const shouldFail = Math.random() < 0.1; // 10% chance of failure
      
      if (shouldFail) {
        throw new Error('Server temporarily unavailable');
      }

      // Store user data in localStorage for the game session
      const userData = {
        email: formData.email,
        registrationDate: new Date().toISOString(),
        sessionId: `session_${Date.now()}`
      };
      
      localStorage.setItem('adsMemoryUser', JSON.stringify(userData));
      
      setUserEmail(formData.email);
      setRegistrationState('success');
      
    } catch (err) {
      console.error('Registration error:', err);
      setError({
        type: 'server',
        message: err.message || 'Failed to create account. Please try again.'
      });
      setRegistrationState('error');
    } finally {
      setIsLoading(false);
    }
  };

  const handleContinueToExpertise = () => {
    navigate('/expertise-selection');
  };

  const handleRetry = () => {
    setError(null);
    setRegistrationState('form');
  };

  const handleGoBack = () => {
    setError(null);
    setRegistrationState('form');
  };

  const renderContent = () => {
    switch (registrationState) {
      case 'success':
        return (
          <SuccessMessage
            email={userEmail}
            onContinue={handleContinueToExpertise}
          />
        );
      
      case 'error':
        return (
          <ErrorMessage
            error={error}
            onRetry={handleRetry}
            onGoBack={handleGoBack}
          />
        );
      
      default:
        return (
          <>
            <WelcomeHeader />
            <RegistrationForm
              onSubmit={handleRegistrationSubmit}
              isLoading={isLoading}
            />
          </>
        );
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader currentPhase="registration" />
      
      <main className="pt-16 pb-8 px-4">
        <div className="max-w-md mx-auto">
          {/* Main Content Card */}
          <div className="bg-card border border-border rounded-2xl shadow-sm p-8">
            {renderContent()}
          </div>
          
          {/* Additional Info */}
          {registrationState === 'form' && (
            <div className="mt-6 text-center">
              <p className="text-sm text-muted-foreground">
                Already have an account?{' '}
                <button
                  className="text-primary hover:underline focus:outline-none focus:underline font-medium"
                  onClick={() => console.log('Sign in clicked')}
                >
                  Sign in here
                </button>
              </p>
            </div>
          )}
        </div>
        
        {/* Background Decoration */}
        <div className="fixed inset-0 -z-10 overflow-hidden pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-primary/5 rounded-full blur-3xl" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/5 rounded-full blur-3xl" />
        </div>
      </main>
    </div>
  );
};

export default UserRegistration;