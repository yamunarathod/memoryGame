import React from 'react';
import Button from '../../../components/ui/Button';

const ContinueButton = ({ isDisabled, onContinue, isLoading }) => {
  return (
    <div className="flex justify-center pt-8">
      <Button
        variant="default"
        size="lg"
        disabled={isDisabled}
        loading={isLoading}
        onClick={onContinue}
        iconName="ArrowRight"
        iconPosition="right"
        className="min-w-[200px]"
      >
        Continue to Assessment
      </Button>
    </div>
  );
};

export default ContinueButton;