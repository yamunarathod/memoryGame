import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressHeader = () => {
  return (
    <div className="text-center mb-8">
      {/* Progress Indicator */}
      <div className="flex items-center justify-center mb-6">
        <div className="flex items-center space-x-3">
          <div className="w-8 h-8 bg-success rounded-full flex items-center justify-center">
            <Icon name="Check" size={16} color="white" strokeWidth={2.5} />
          </div>
          <div className="w-12 h-0.5 bg-primary"></div>
          <div className="w-8 h-8 bg-primary rounded-full flex items-center justify-center">
            <span className="text-white text-sm font-semibold">2</span>
          </div>
          <div className="w-12 h-0.5 bg-muted"></div>
          <div className="w-8 h-8 bg-muted border border-border rounded-full flex items-center justify-center">
            <span className="text-muted-foreground text-sm font-semibold">3</span>
          </div>
        </div>
      </div>

      {/* Title and Description */}
      <h1 className="text-3xl font-bold text-foreground mb-4">
        Choose Your Expertise Level
      </h1>
      <p className="text-muted-foreground text-lg max-w-2xl mx-auto leading-relaxed">
        Help us customize your assessment experience by selecting your current knowledge level in advertising and marketing.
      </p>
    </div>
  );
};

export default ProgressHeader;