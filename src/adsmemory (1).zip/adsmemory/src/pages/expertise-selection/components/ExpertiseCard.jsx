import React from 'react';
import Icon from '../../../components/AppIcon';

const ExpertiseCard = ({ 
  id, 
  title, 
  description, 
  icon, 
  isSelected, 
  onSelect,
  features 
}) => {
  return (
    <div
      onClick={() => onSelect(id)}
      className={`relative p-6 rounded-xl border-2 cursor-pointer transition-all duration-300 hover:shadow-lg ${
        isSelected
          ? 'border-primary bg-primary/5 shadow-md'
          : 'border-border bg-card hover:border-primary/50'
      }`}
    >
      {/* Selection Indicator */}
      {isSelected && (
        <div className="absolute top-4 right-4 w-6 h-6 bg-primary rounded-full flex items-center justify-center">
          <Icon name="Check" size={16} color="white" strokeWidth={2.5} />
        </div>
      )}

      {/* Icon */}
      <div className={`w-12 h-12 rounded-lg flex items-center justify-center mb-4 ${
        isSelected ? 'bg-primary' : 'bg-muted'
      }`}>
        <Icon 
          name={icon} 
          size={24} 
          color={isSelected ? 'white' : 'var(--color-foreground)'} 
          strokeWidth={2}
        />
      </div>

      {/* Title */}
      <h3 className={`text-xl font-semibold mb-3 ${
        isSelected ? 'text-primary' : 'text-foreground'
      }`}>
        {title}
      </h3>

      {/* Description */}
      <p className="text-muted-foreground text-sm mb-4 leading-relaxed">
        {description}
      </p>

      {/* Features */}
      <ul className="space-y-2">
        {features.map((feature, index) => (
          <li key={index} className="flex items-center text-sm text-muted-foreground">
            <Icon 
              name="CheckCircle2" 
              size={16} 
              className={`mr-2 ${isSelected ? 'text-primary' : 'text-muted-foreground'}`}
            />
            {feature}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ExpertiseCard;