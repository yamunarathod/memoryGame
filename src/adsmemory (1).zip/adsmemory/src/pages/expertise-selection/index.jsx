import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../../components/ui/AppHeader';
import ExpertiseCard from './components/ExpertiseCard';
import ContinueButton from './components/ContinueButton';
import ProgressHeader from './components/ProgressHeader';

const ExpertiseSelection = () => {
  const navigate = useNavigate();
  const [selectedExpertise, setSelectedExpertise] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // Mock user session data
  const userSession = {
    name: "Sarah Johnson",
    email: "sarah.johnson@email.com",
    avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=150&h=150&fit=crop&crop=face"
  };

  const expertiseOptions = [
    {
      id: 'new-to-ads',
      title: 'New to Ads',
      description: 'Perfect for beginners who are just starting their journey in advertising and marketing. This level focuses on fundamental concepts and basic terminology.',
      icon: 'GraduationCap',
      features: [
        'Basic advertising concepts',
        'Simple terminology and definitions',
        'Foundational marketing principles',
        'Beginner-friendly questions'
      ]
    },
    {
      id: 'ad-expert',
      title: 'Ad Expert',
      description: 'Designed for experienced professionals with substantial knowledge in advertising, marketing strategies, and industry best practices.',
      icon: 'Trophy',
      features: [
        'Advanced advertising strategies',
        'Complex campaign analysis',
        'Industry-specific terminology',
        'Professional-level challenges'
      ]
    }
  ];

  const handleExpertiseSelect = (expertiseId) => {
    setSelectedExpertise(expertiseId);
  };

  const handleContinue = async () => {
    if (!selectedExpertise) return;

    setIsLoading(true);
    
    // Simulate API call to save expertise selection
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Store expertise level in localStorage for later use
    localStorage.setItem('userExpertise', selectedExpertise);
    localStorage.setItem('userSession', JSON.stringify(userSession));
    
    setIsLoading(false);
    navigate('/question-memorization');
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader currentPhase="expertise" userSession={userSession} />
      
      <main className="pt-20 pb-12 px-4">
        <div className="max-w-4xl mx-auto">
          <ProgressHeader />
          
          {/* Expertise Selection Cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {expertiseOptions.map((option) => (
              <ExpertiseCard
                key={option.id}
                id={option.id}
                title={option.title}
                description={option.description}
                icon={option.icon}
                features={option.features}
                isSelected={selectedExpertise === option.id}
                onSelect={handleExpertiseSelect}
              />
            ))}
          </div>

          {/* Continue Button */}
          <ContinueButton
            isDisabled={!selectedExpertise}
            isLoading={isLoading}
            onContinue={handleContinue}
          />

          {/* Help Text */}
          <div className="text-center mt-8">
            <p className="text-sm text-muted-foreground">
              Don't worry, you can always challenge yourself with different levels later!
            </p>
          </div>
        </div>
      </main>
    </div>
  );
};

export default ExpertiseSelection;