import React, { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import AppHeader from '../../components/ui/AppHeader';
import CountdownTimer from './components/CountdownTimer';
import QuestionCard from './components/QuestionCard';
import AnswerCard from './components/AnswerCard';
import ProgressIndicator from './components/ProgressIndicator';
import GameControls from './components/GameControls';
import FeedbackModal from './components/FeedbackModal';
import Button from '../../components/ui/Button';
import Icon from '../../components/AppIcon';

const DragAndDropMatching = () => {
  const navigate = useNavigate();
  
  // Mock data for questions and answers
  const mockQuestions = [
    {
      id: 1,
      text: "What is the primary goal of brand awareness campaigns?",
      correctAnswerId: 1
    },
    {
      id: 2,
      text: "Which metric measures the cost of acquiring a new customer through advertising?",
      correctAnswerId: 2
    },
    {
      id: 3,
      text: "What does CTR stand for in digital advertising?",
      correctAnswerId: 3
    },
    {
      id: 4,
      text: "Which advertising model charges advertisers only when users click on their ads?",
      correctAnswerId: 4
    },
    {
      id: 5,
      text: "What is the term for showing ads to users who have previously visited your website?",
      correctAnswerId: 5
    },
    {
      id: 6,
      text: "Which social media platform is best known for professional networking and B2B advertising?",
      correctAnswerId: 6
    }
  ];

  const mockAnswers = [
    { id: 1, text: "To increase recognition and recall of a brand among target audiences" },
    { id: 2, text: "Customer Acquisition Cost (CAC)" },
    { id: 3, text: "Click-Through Rate" },
    { id: 4, text: "Pay-Per-Click (PPC)" },
    { id: 5, text: "Retargeting or Remarketing" },
    { id: 6, text: "LinkedIn" }
  ];

  // Shuffle answers for display
  const [shuffledAnswers] = useState(() => {
    const shuffled = [...mockAnswers];
    for (let i = shuffled.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
    }
    return shuffled;
  });

  // Game state
  const [matches, setMatches] = useState({});
  const [draggedAnswer, setDraggedAnswer] = useState(null);
  const [dragOverQuestion, setDragOverQuestion] = useState(null);
  const [incorrectAnswers, setIncorrectAnswers] = useState(new Set());
  const [isPaused, setIsPaused] = useState(false);
  const [hintsRemaining, setHintsRemaining] = useState(3);
  const [correctMatches, setCorrectMatches] = useState(0);
  const [incorrectAttempts, setIncorrectAttempts] = useState(0);
  const [gameCompleted, setGameCompleted] = useState(false);
  
  // Feedback modal state
  const [feedback, setFeedback] = useState({
    isVisible: false,
    type: 'info',
    message: ''
  });

  // User session from localStorage
  const [userSession] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('userSession')) || null;
    } catch {
      return null;
    }
  });

  // Handle successful match
  const handleCorrectMatch = useCallback((questionId, answerId) => {
    setMatches(prev => ({ ...prev, [questionId]: answerId }));
    setCorrectMatches(prev => prev + 1);
    setIncorrectAnswers(prev => {
      const newSet = new Set(prev);
      newSet.delete(answerId);
      return newSet;
    });
    
    setFeedback({
      isVisible: true,
      type: 'success',
      message: 'Perfect match! Well done.'
    });
  }, []);

  // Handle incorrect match
  const handleIncorrectMatch = useCallback((answerId) => {
    setIncorrectAttempts(prev => prev + 1);
    setIncorrectAnswers(prev => new Set([...prev, answerId]));
    
    setFeedback({
      isVisible: true,
      type: 'error',
      message: 'Not quite right. Try again!'
    });

    // Remove error state after 2 seconds
    setTimeout(() => {
      setIncorrectAnswers(prev => {
        const newSet = new Set(prev);
        newSet.delete(answerId);
        return newSet;
      });
    }, 2000);
  }, []);

  // Handle drop event
  const handleDrop = useCallback((questionId, answerId) => {
    const question = mockQuestions.find(q => q.id === questionId);
    const answerIdNum = parseInt(answerId);
    
    if (question && question.correctAnswerId === answerIdNum) {
      handleCorrectMatch(questionId, answerIdNum);
    } else {
      handleIncorrectMatch(answerIdNum);
    }
    
    setDragOverQuestion(null);
  }, [handleCorrectMatch, handleIncorrectMatch]);

  // Handle drag events
  const handleDragStart = useCallback((answerId) => {
    setDraggedAnswer(answerId);
  }, []);

  const handleDragEnd = useCallback(() => {
    setDraggedAnswer(null);
    setDragOverQuestion(null);
  }, []);

  const handleDragOver = useCallback((questionId) => {
    setDragOverQuestion(questionId);
  }, []);

  const handleDragLeave = useCallback(() => {
    setDragOverQuestion(null);
  }, []);

  // Game control handlers
  const handlePause = () => setIsPaused(true);
  const handleResume = () => setIsPaused(false);
  
  const handleHint = () => {
    if (hintsRemaining > 0) {
      setHintsRemaining(prev => prev - 1);
      
      // Find first unmatched question
      const unmatchedQuestion = mockQuestions.find(q => !matches[q.id]);
      if (unmatchedQuestion) {
        const correctAnswer = mockAnswers.find(a => a.id === unmatchedQuestion.correctAnswerId);
        setFeedback({
          isVisible: true,
          type: 'info',
          message: `Hint: Question ${unmatchedQuestion.id} matches with "${correctAnswer?.text.substring(0, 30)}..."`
        });
      }
    }
  };

  const handleSkip = () => {
    if (window.confirm('Are you sure you want to skip to results? Your current progress will be saved.')) {
      handleGameComplete();
    }
  };

  const handleExit = () => {
    if (window.confirm('Are you sure you want to exit? All progress will be lost.')) {
      navigate('/user-registration');
    }
  };

  // Handle time up
  const handleTimeUp = useCallback(() => {
    setGameCompleted(true);
    setFeedback({
      isVisible: true,
      type: 'warning',
      message: 'Time\'s up! Let\'s see how you did.',
      autoClose: false
    });
  }, []);

  // Handle game completion
  const handleGameComplete = useCallback(() => {
    const finalScore = {
      totalQuestions: mockQuestions.length,
      correctMatches,
      incorrectAttempts,
      timeRemaining: !gameCompleted,
      accuracy: correctMatches > 0 ? (correctMatches / (correctMatches + incorrectAttempts)) * 100 : 0,
      percentage: (correctMatches / mockQuestions.length) * 100
    };

    // Save results to localStorage
    localStorage.setItem('gameResults', JSON.stringify(finalScore));
    
    // Navigate to results
    setTimeout(() => {
      navigate('/results-and-feedback');
    }, 1500);
  }, [correctMatches, incorrectAttempts, gameCompleted, navigate]);

  // Check for game completion
  useEffect(() => {
    if (Object.keys(matches).length === mockQuestions.length && !gameCompleted) {
      setGameCompleted(true);
      setFeedback({
        isVisible: true,
        type: 'success',
        message: 'Congratulations! You\'ve matched all questions correctly!',
        autoClose: false
      });
      setTimeout(() => {
        handleGameComplete();
      }, 2000);
    }
  }, [matches, gameCompleted, handleGameComplete]);

  // Close feedback modal
  const closeFeedback = () => {
    setFeedback(prev => ({ ...prev, isVisible: false }));
    if (gameCompleted) {
      handleGameComplete();
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AppHeader currentPhase="matching" userSession={userSession} />
      
      <div className="pt-16">
        <div className="container mx-auto px-4 py-8 max-w-7xl">
          {/* Header Section */}
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-foreground mb-2">
              Drag & Drop Matching
            </h1>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Match each question with its correct answer by dragging the answer cards to the corresponding question zones. 
              You have 3 minutes to complete all matches.
            </p>
          </div>

          {/* Timer and Controls */}
          <div className="mb-6">
            <CountdownTimer
              initialTime={180}
              onTimeUp={handleTimeUp}
              isActive={!isPaused && !gameCompleted}
            />
            
            <GameControls
              onPause={handlePause}
              onResume={handleResume}
              onSkip={handleSkip}
              onHint={handleHint}
              onExit={handleExit}
              isPaused={isPaused}
              canSkip={Object.keys(matches).length > 0}
              hintsRemaining={hintsRemaining}
            />
            
            <ProgressIndicator
              totalQuestions={mockQuestions.length}
              matchedCount={Object.keys(matches).length}
              correctMatches={correctMatches}
              incorrectAttempts={incorrectAttempts}
            />
          </div>

          {/* Game Board */}
          <div className="grid lg:grid-cols-2 gap-8">
            {/* Questions Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="HelpCircle" size={20} className="text-primary" />
                <h2 className="text-xl font-semibold text-foreground">Questions</h2>
                <span className="text-sm text-muted-foreground">
                  ({Object.keys(matches).length}/{mockQuestions.length} matched)
                </span>
              </div>
              
              {mockQuestions.map(question => (
                <QuestionCard
                  key={question.id}
                  question={question}
                  isMatched={!!matches[question.id]}
                  matchedAnswer={matches[question.id] ? mockAnswers.find(a => a.id === matches[question.id]) : null}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  isDragOver={dragOverQuestion === question.id}
                />
              ))}
            </div>

            {/* Answers Section */}
            <div className="space-y-4">
              <div className="flex items-center space-x-2 mb-4">
                <Icon name="MessageSquare" size={20} className="text-secondary" />
                <h2 className="text-xl font-semibold text-foreground">Answers</h2>
                <span className="text-sm text-muted-foreground">
                  (Drag to match)
                </span>
              </div>
              
              <div className="space-y-3">
                {shuffledAnswers.map(answer => (
                  <AnswerCard
                    key={answer.id}
                    answer={answer}
                    isMatched={Object.values(matches).includes(answer.id)}
                    isIncorrect={incorrectAnswers.has(answer.id)}
                    onDragStart={handleDragStart}
                    onDragEnd={handleDragEnd}
                  />
                ))}
              </div>
              
              {/* Mobile Instructions */}
              <div className="lg:hidden mt-6 p-4 bg-muted/50 rounded-lg">
                <div className="flex items-center space-x-2 mb-2">
                  <Icon name="Smartphone" size={16} className="text-primary" />
                  <span className="text-sm font-medium text-foreground">Mobile Instructions</span>
                </div>
                <p className="text-xs text-muted-foreground">
                  Tap and hold an answer card, then drag it to the matching question's drop zone above.
                </p>
              </div>
            </div>
          </div>

          {/* Game Paused Overlay */}
          {isPaused && (
            <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-center justify-center">
              <div className="bg-card border border-border rounded-lg p-8 max-w-sm mx-4 text-center">
                <Icon name="Pause" size={48} className="text-warning mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-foreground mb-2">Game Paused</h3>
                <p className="text-muted-foreground mb-6">
                  Take your time. Click Resume when you're ready to continue.
                </p>
                <Button
                  onClick={handleResume}
                  iconName="Play"
                  iconPosition="left"
                  fullWidth
                >
                  Resume Game
                </Button>
              </div>
            </div>
          )}

          {/* Feedback Modal */}
          <FeedbackModal
            isVisible={feedback.isVisible}
            type={feedback.type}
            message={feedback.message}
            onClose={closeFeedback}
            autoClose={feedback.type !== 'warning' && !gameCompleted}
          />
        </div>
      </div>
    </div>
  );
};

export default DragAndDropMatching;