import React from 'react';
import Icon from '../../../components/AppIcon';

const QuestionCard = ({ question, isMatched, matchedAnswer, onDrop, onDragOver, onDragLeave, isDragOver }) => {
  const handleDrop = (e) => {
    e.preventDefault();
    const answerId = e.dataTransfer.getData('text/plain');
    onDrop(question.id, answerId);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    onDragOver(question.id);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    onDragLeave();
  };

  return (
    <div 
      className={`relative p-4 rounded-lg border-2 transition-all duration-200 ${
        isMatched 
          ? 'bg-success/10 border-success' 
          : isDragOver 
          ? 'bg-primary/10 border-primary border-dashed' :'bg-card border-border hover:border-primary/50'
      }`}
      onDrop={handleDrop}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
    >
      {/* Question Number */}
      <div className="flex items-start space-x-3">
        <div className={`flex-shrink-0 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
          isMatched ? 'bg-success text-white' : 'bg-muted text-muted-foreground'
        }`}>
          {question.id}
        </div>
        
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground leading-relaxed">
            {question.text}
          </p>
        </div>
      </div>

      {/* Drop Zone Indicator */}
      {!isMatched && (
        <div className={`mt-3 p-3 border-2 border-dashed rounded-lg transition-all duration-200 ${
          isDragOver 
            ? 'border-primary bg-primary/5' :'border-muted-foreground/30 bg-muted/30'
        }`}>
          <div className="flex items-center justify-center space-x-2">
            <Icon name="Target" size={16} className="text-muted-foreground" />
            <span className="text-xs text-muted-foreground">
              {isDragOver ? 'Release to match' : 'Drop answer here'}
            </span>
          </div>
        </div>
      )}

      {/* Matched Answer Display */}
      {isMatched && matchedAnswer && (
        <div className="mt-3 p-3 bg-success/10 border border-success/30 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span className="text-sm text-success font-medium">Matched:</span>
          </div>
          <p className="text-sm text-foreground mt-1">{matchedAnswer.text}</p>
        </div>
      )}

      {/* Match Status Icon */}
      {isMatched && (
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-success rounded-full flex items-center justify-center">
          <Icon name="Check" size={14} color="white" strokeWidth={3} />
        </div>
      )}
    </div>
  );
};

export default QuestionCard;