import React from 'react';
import Icon from '../../../components/AppIcon';

const ProgressIndicator = ({ totalQuestions, matchedCount, correctMatches, incorrectAttempts }) => {
  const progressPercentage = (matchedCount / totalQuestions) * 100;
  const accuracy = matchedCount > 0 ? (correctMatches / (correctMatches + incorrectAttempts)) * 100 : 0;

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-foreground">Progress</h3>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-1">
            <Icon name="Target" size={16} className="text-success" />
            <span className="text-sm font-medium text-success">{correctMatches}</span>
          </div>
          <div className="flex items-center space-x-1">
            <Icon name="X" size={16} className="text-error" />
            <span className="text-sm font-medium text-error">{incorrectAttempts}</span>
          </div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="mb-4">
        <div className="flex justify-between items-center mb-2">
          <span className="text-sm text-muted-foreground">Completion</span>
          <span className="text-sm font-medium text-foreground">
            {matchedCount}/{totalQuestions} ({Math.round(progressPercentage)}%)
          </span>
        </div>
        <div className="w-full bg-muted rounded-full h-3">
          <div 
            className="h-3 bg-primary rounded-full transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          />
        </div>
      </div>

      {/* Accuracy Indicator */}
      {(correctMatches + incorrectAttempts) > 0 && (
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-muted-foreground">Accuracy</span>
            <span className={`text-sm font-medium ${
              accuracy >= 80 ? 'text-success' : accuracy >= 60 ? 'text-warning' : 'text-error'
            }`}>
              {Math.round(accuracy)}%
            </span>
          </div>
          <div className="w-full bg-muted rounded-full h-2">
            <div 
              className={`h-2 rounded-full transition-all duration-500 ${
                accuracy >= 80 ? 'bg-success' : accuracy >= 60 ? 'bg-warning' : 'bg-error'
              }`}
              style={{ width: `${accuracy}%` }}
            />
          </div>
        </div>
      )}

      {/* Status Messages */}
      <div className="space-y-2">
        {matchedCount === totalQuestions && (
          <div className="flex items-center space-x-2 p-2 bg-success/10 border border-success/30 rounded-lg">
            <Icon name="CheckCircle" size={16} className="text-success" />
            <span className="text-sm text-success font-medium">All questions matched!</span>
          </div>
        )}
        
        {matchedCount > 0 && matchedCount < totalQuestions && (
          <div className="flex items-center space-x-2 p-2 bg-primary/10 border border-primary/30 rounded-lg">
            <Icon name="Zap" size={16} className="text-primary" />
            <span className="text-sm text-primary font-medium">
              {totalQuestions - matchedCount} questions remaining
            </span>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProgressIndicator;