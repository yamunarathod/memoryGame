import React from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const GameControls = ({ 
  onPause, 
  onResume, 
  onSkip, 
  onHint, 
  isPaused, 
  canSkip, 
  hintsRemaining,
  onExit 
}) => {
  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Icon name="Gamepad2" size={20} className="text-primary" />
          <span className="text-sm font-medium text-foreground">Game Controls</span>
        </div>
        
        <div className="flex items-center space-x-2">
          {/* Pause/Resume Button */}
          <Button
            variant="outline"
            size="sm"
            onClick={isPaused ? onResume : onPause}
            iconName={isPaused ? "Play" : "Pause"}
            iconPosition="left"
            iconSize={14}
          >
            {isPaused ? 'Resume' : 'Pause'}
          </Button>

          {/* Hint Button */}
          <Button
            variant="secondary"
            size="sm"
            onClick={onHint}
            disabled={hintsRemaining <= 0}
            iconName="Lightbulb"
            iconPosition="left"
            iconSize={14}
          >
            Hint ({hintsRemaining})
          </Button>

          {/* Skip Button */}
          {canSkip && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onSkip}
              iconName="SkipForward"
              iconPosition="left"
              iconSize={14}
            >
              Skip
            </Button>
          )}

          {/* Exit Button */}
          <Button
            variant="destructive"
            size="sm"
            onClick={onExit}
            iconName="X"
            iconPosition="left"
            iconSize={14}
          >
            Exit
          </Button>
        </div>
      </div>

      {isPaused && (
        <div className="mt-4 p-3 bg-warning/10 border border-warning/30 rounded-lg">
          <div className="flex items-center space-x-2">
            <Icon name="Pause" size={16} className="text-warning" />
            <span className="text-sm text-warning font-medium">Game Paused</span>
          </div>
          <p className="text-xs text-muted-foreground mt-1">
            Timer is paused. Click Resume to continue.
          </p>
        </div>
      )}
    </div>
  );
};

export default GameControls;