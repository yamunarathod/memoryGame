import React, { useState } from 'react';
import Icon from '../../../components/AppIcon';

const AnswerCard = ({ answer, isMatched, isIncorrect, onDragStart, onDragEnd }) => {
  const [isDragging, setIsDragging] = useState(false);

  const handleDragStart = (e) => {
    e.dataTransfer.setData('text/plain', answer.id);
    setIsDragging(true);
    onDragStart(answer.id);
  };

  const handleDragEnd = () => {
    setIsDragging(false);
    onDragEnd();
  };

  const handleTouchStart = (e) => {
    // Add touch feedback
    e.currentTarget.style.transform = 'scale(0.95)';
  };

  const handleTouchEnd = (e) => {
    // Reset touch feedback
    e.currentTarget.style.transform = 'scale(1)';
  };

  if (isMatched) {
    return null; // Hide matched answers
  }

  return (
    <div
      draggable={!isMatched}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
      className={`relative p-4 rounded-lg border-2 cursor-grab active:cursor-grabbing transition-all duration-200 select-none ${
        isDragging 
          ? 'opacity-50 scale-95 border-primary bg-primary/10' 
          : isIncorrect
          ? 'border-error bg-error/10 animate-pulse' :'bg-card border-border hover:border-primary/50 hover:shadow-md'
      } ${!isMatched ? 'touch-manipulation' : ''}`}
      style={{
        touchAction: 'none',
        userSelect: 'none'
      }}
    >
      {/* Drag Handle */}
      <div className="flex items-start space-x-3">
        <div className="flex-shrink-0 mt-1">
          <Icon 
            name="GripVertical" 
            size={16} 
            className={`${isDragging ? 'text-primary' : 'text-muted-foreground'}`} 
          />
        </div>
        
        <div className="flex-1">
          <p className="text-sm font-medium text-foreground leading-relaxed">
            {answer.text}
          </p>
        </div>
      </div>

      {/* Drag Indicator */}
      {isDragging && (
        <div className="absolute inset-0 border-2 border-dashed border-primary rounded-lg bg-primary/5 flex items-center justify-center">
          <div className="flex items-center space-x-2">
            <Icon name="Move" size={16} className="text-primary" />
            <span className="text-xs text-primary font-medium">Dragging...</span>
          </div>
        </div>
      )}

      {/* Error State */}
      {isIncorrect && (
        <div className="absolute -top-2 -right-2 w-6 h-6 bg-error rounded-full flex items-center justify-center">
          <Icon name="X" size={14} color="white" strokeWidth={3} />
        </div>
      )}

      {/* Touch Hint */}
      <div className="absolute bottom-1 right-1 opacity-30">
        <Icon name="Hand" size={12} className="text-muted-foreground" />
      </div>
    </div>
  );
};

export default AnswerCard;