import React, { useEffect } from 'react';
import Button from '../../../components/ui/Button';
import Icon from '../../../components/AppIcon';

const FeedbackModal = ({ 
  isVisible, 
  type, 
  message, 
  onClose, 
  autoClose = true,
  duration = 2000 
}) => {
  React.useEffect(() => {
    if (isVisible && autoClose) {
      const timer = setTimeout(() => {
        onClose();
      }, duration);
      return () => clearTimeout(timer);
    }
  }, [isVisible, autoClose, duration, onClose]);

  if (!isVisible) return null;

  const getModalConfig = () => {
    switch (type) {
      case 'success':
        return {
          icon: 'CheckCircle',
          iconColor: 'text-success',
          bgColor: 'bg-success/10',
          borderColor: 'border-success/30',
          textColor: 'text-success'
        };
      case 'error':
        return {
          icon: 'XCircle',
          iconColor: 'text-error',
          bgColor: 'bg-error/10',
          borderColor: 'border-error/30',
          textColor: 'text-error'
        };
      case 'warning':
        return {
          icon: 'AlertTriangle',
          iconColor: 'text-warning',
          bgColor: 'bg-warning/10',
          borderColor: 'border-warning/30',
          textColor: 'text-warning'
        };
      case 'info':
      default:
        return {
          icon: 'Info',
          iconColor: 'text-primary',
          bgColor: 'bg-primary/10',
          borderColor: 'border-primary/30',
          textColor: 'text-primary'
        };
    }
  };

  const config = getModalConfig();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-black/20 backdrop-blur-sm"
        onClick={onClose}
      />
      
      {/* Modal */}
      <div className={`relative bg-card border-2 ${config.borderColor} rounded-lg p-6 max-w-sm w-full mx-4 shadow-lg animate-fade-in`}>
        <div className="flex items-center space-x-3 mb-4">
          <div className={`w-10 h-10 rounded-full ${config.bgColor} flex items-center justify-center`}>
            <Icon name={config.icon} size={20} className={config.iconColor} />
          </div>
          <div className="flex-1">
            <h3 className={`font-semibold ${config.textColor} capitalize`}>
              {type === 'success' ? 'Correct!' : type === 'error' ? 'Incorrect!' : type}
            </h3>
          </div>
        </div>
        
        <p className="text-sm text-foreground mb-4 leading-relaxed">
          {message}
        </p>
        
        {!autoClose && (
          <div className="flex justify-end">
            <Button
              variant="outline"
              size="sm"
              onClick={onClose}
              iconName="X"
              iconPosition="left"
              iconSize={14}
            >
              Close
            </Button>
          </div>
        )}
        
        {/* Auto-close progress bar */}
        {autoClose && (
          <div className="absolute bottom-0 left-0 right-0 h-1 bg-muted rounded-b-lg overflow-hidden">
            <div 
              className={`h-full ${config.iconColor.replace('text-', 'bg-')} animate-progress`}
              style={{
                animation: `progress ${duration}ms linear forwards`
              }}
            />
          </div>
        )}
      </div>
      
      <style jsx>{`
        @keyframes progress {
          from { width: 100%; }
          to { width: 0%; }
        }
        .animate-progress {
          animation: progress ${duration}ms linear forwards;
        }
        .animate-fade-in {
          animation: fadeIn 0.2s ease-out forwards;
        }
        @keyframes fadeIn {
          from { opacity: 0; transform: scale(0.95); }
          to { opacity: 1; transform: scale(1); }
        }
      `}</style>
    </div>
  );
};

export default FeedbackModal;