import React, { useState, useEffect } from 'react';
import Icon from '../../../components/AppIcon';

const CountdownTimer = ({ initialTime = 180, onTimeUp, isActive = true }) => {
  const [timeLeft, setTimeLeft] = useState(initialTime);

  useEffect(() => {
    if (!isActive || timeLeft <= 0) return;

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          onTimeUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeLeft, onTimeUp, isActive]);

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getTimerColor = () => {
    if (timeLeft <= 30) return 'text-error';
    if (timeLeft <= 60) return 'text-warning';
    return 'text-primary';
  };

  const getProgressWidth = () => {
    return (timeLeft / initialTime) * 100;
  };

  return (
    <div className="bg-card border border-border rounded-lg p-4 mb-6">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-2">
          <Icon name="Clock" size={20} className="text-muted-foreground" />
          <span className="text-sm font-medium text-muted-foreground">Time Remaining</span>
        </div>
        <div className={`text-2xl font-bold ${getTimerColor()}`}>
          {formatTime(timeLeft)}
        </div>
      </div>
      
      {/* Progress Bar */}
      <div className="w-full bg-muted rounded-full h-2">
        <div 
          className={`h-2 rounded-full transition-all duration-1000 ${
            timeLeft <= 30 ? 'bg-error' : timeLeft <= 60 ? 'bg-warning' : 'bg-primary'
          }`}
          style={{ width: `${getProgressWidth()}%` }}
        />
      </div>
      
      {timeLeft <= 30 && (
        <div className="flex items-center justify-center mt-2">
          <Icon name="AlertTriangle" size={16} className="text-error mr-1" />
          <span className="text-xs text-error font-medium">Hurry up! Time is running out</span>
        </div>
      )}
    </div>
  );
};

export default CountdownTimer;